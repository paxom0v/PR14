package com.example.pr14pahomovpr21101;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Head extends Activity implements View.OnClickListener {
    View view;
    @SuppressLint("MissingInflatedId")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_head);
        view = findViewById(R.id.view2);
        view.setOnClickListener(this);
    }
    public void onClick(View view) {
Intent intent = new Intent(this, Profile.class);
startActivity(intent);
    }
    }