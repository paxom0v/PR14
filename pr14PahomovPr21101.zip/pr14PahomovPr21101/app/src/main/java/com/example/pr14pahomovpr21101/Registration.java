package com.example.pr14pahomovpr21101;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Registration extends Activity implements View.OnClickListener {

    TextView text;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        text = findViewById(R.id.textInput);
        text.setOnClickListener(this);
    }
    public void onClick(View view) {
        Intent intent = new Intent(this, Input.class);
        startActivity(intent);
    }

    }